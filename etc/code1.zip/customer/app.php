<?php

	$logged_in = (isset ($_SESSION['admin'])) ? TRUE : FALSE;

?>
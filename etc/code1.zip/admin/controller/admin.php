<?php
	
	$js = '
	<script type="text/javascript" charset="utf-8">
		$(document)
			.ready(function() {
				
			});
	</script>';

?>
<?php

	$a = 1;
	while ($a <= 126) {
//		mysqli_query ($mysqli, "INSERT INTO `issue_collection` (`issue_id`, `collection_id`) VALUES ('" . $a . "', 13)");
//		echo mysqli_error ($mysqli);
		$a++;
	}

?>
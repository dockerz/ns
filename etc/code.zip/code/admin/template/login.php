<section class="actions show">
	<div class="container">
		<form action="<?php echo $l; ?>" method="post" accept-charset="utf-8">
			<p class="form"><input type="text" name="e" placeholder="email" /> <input type="password" name="p" placeholder="password" /><button type="submit">login</button></p>
		</form>
	</div>
</section>
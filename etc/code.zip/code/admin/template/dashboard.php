<section class="list">
	<div class="container">
		<p><strong><?php echo $data['issues']; ?></strong> issues</p>
		<p><strong><?php echo $data['users']; ?></strong> users</p>
		<p><strong><?php echo $data['collections']; ?></strong> collections</p>
	</div>
</section>
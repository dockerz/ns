	<script src="<?php echo ROOT; ?>includes/js/jq-1.9.1.js"></script>
	<script src="<?php echo ROOT; ?>includes/js/default.js"></script>
	<script type="text/javascript" charset="utf-8">
		page = {
			"location": "<?php echo LOCATION; ?>",
			"sort": "<?php echo SORT; ?>"
		}
	</script>
	<?php echo $js; ?>
</body>
</html>